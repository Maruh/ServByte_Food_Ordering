export class Order {
    totalQuantity:number=0;
    totalPrice:number=0;

}

