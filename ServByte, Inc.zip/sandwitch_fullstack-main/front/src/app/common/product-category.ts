export class ProductCategory {

    id:number =0;
    name:string ='';

}
