export class State {
    id:number=0;
    name:string="";
}
