export class User {
    name:string="";
    last_name="";
    phone_number:number=0;
    email_address:string="";
}
