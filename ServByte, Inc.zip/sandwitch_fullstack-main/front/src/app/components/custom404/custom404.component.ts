import { Component, OnInit } from '@angular/core';

//component for catch unresolved routes
@Component({
  selector: 'app-custom404',
  templateUrl: './custom404.component.html',
  styleUrls: ['./custom404.component.css']
})
export class Custom404Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
