package pl.tiuprojekt.sandwitch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SandwitchApplicationTests {

    @Test
    void contextLoads() {
    }

}
